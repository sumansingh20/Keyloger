# Advance Keylogger

<p align="center">
  <img src="https://cdn.discordapp.com/attachments/787260295860191254/1005556601823952946/logo.png" width=500/>
</p>

## What is Keylogger ?

_The action of recording (logging) the keys struck on a keyboard, often discreetly, so that the person using the keyboard is unaware that their activities are being observed is known as keystroke logging, also known as keylogging or keyboard capture. The person who is running the logging program can then obtain the data. Keylogger is most often used to steal passwords and other confidential information._

_Even Microsoft has openly confirmed that the final version of Windows 10 features a built-in keylogger “to improve typing and writing functions.”_

## Type of Keyloggers
*There are two types of keyloggers:*

* ### Software-Based Keyloggers
  * Features that collect user information without relying solely on keyboard key presses can be added to software keyloggers.
  * Logging of the clipboard The software can capture anything that has been copied to the clipboard.
  * Logging on the computer screen. To collect graphics-based information, screenshots are taken.
  * Capturing text in a control programmatically.
  * Search engine queries, instant messenger talks, FTP downloads, and other Internet-based activities are all being recorded (including the bandwidth used).

* ### Hardware-Based Keyloggers
  * Typical Hardware Keylogger is a hardware circuit that is installed anywhere between the computer keyboard and the computer for keystroke logging.
  * Hardware keyloggers have an advantage over software keyloggers in that they can start logging as soon as the machine is switched on.
  * Hardware-based keyloggers do not require the installation of any software because they operate at the hardware level of a computer system.
  * A hardware keylogger’s memory size can range from a few kilobytes to several terabytes, with each keystroke recorded typically consuming a byte

## How to detect and remove Keylogger
_Are there telltale signs that your device is hosting a keylogger? The answer is, it depends. Like most malware, you can use a good antivirus/anti-malware scanner to find and remove keyloggers._

_Keyloggers of poorer quality (such as the malware variety) might reveal themselves in a number of ways. The software might subtly degrade smartphone screenshots to a noticeable degree. On all devices, there could be a slowdown in web browsing performance. Or there’s a distinct lag in your mouse movement or keystrokes, or what you are actually typing doesn’t show up onscreen. You might even get an error message when loading graphics or web pages. All in all, something just seems “off.”_

_The well-designed commercial grade of keylogger usually works flawlessly, so it does not affect system performance at all. If the keylogger is sending reports to a remote operator, it disguises itself as normal files or traffic. Some of the programs will even display a notice on the screen that the system is being monitored—such as in a corporate computing environment. Others can reinstall themselves if users somehow succeed in finding them and attempt to remove them._

_Of course, the best way to protect yourself and your equipment from falling victim to keyloggers is to scan your system regularly with a quality cybersecurity program. For instance. It uses heuristic analysis, signature recognition, and identification of typical keylogger behavior associated with keystroke and screenshot capturing to first find the malware, and then remove it._

## Safe Side
_Avoid keyloggers by avoiding the user mistakes that lead to their ability to infect phones and computers. It starts with keeping your operating system, your applications, and web browsers up to date with the latest security patches. Always be skeptical about any attachments you receive, especially unexpected ones even if they seem to come from someone you know. When in doubt, contact the sender to ask. Keep your passwords long and complex, and avoid using the same one for different services._

_Real-time, always-on antivirus/anti-malware protection is the gold standard for preventing not only infection from a keylogger, but also from all other associated malware threats. For all platforms and devices, from Windows and Android, Mac and iPhones, to business environments._

## Disclaimer
_This tool is for educational purposes only, the author do not endorse or promote any illegal activity and are not responsible for any damage done henceforth._

## License
_This program is free software; you can redistribute it and/or modify it under the terms of the MIT License (MIT). See [LICENSE](LICENSE) for more details._
